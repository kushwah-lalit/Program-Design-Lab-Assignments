#include <stdio.h>
#include <stdlib.h>

int main() {
    int N;
    scanf("%d",&N);
    int *input=(int*)malloc(N*sizeof(int));
    for(int i=0;i<N;i++){
        scanf("%d",input+i);
    }
    for(int i=1;i<N;i++){
        for(int j=0;j<N-1;j++){
            if (*(input+j)>*(input+j+1)){
                //swap
                int x=*(input+j);
                *(input+j)=*(input+j+1);
                *(input+j+1)=x;
            }
        }
    }
    for(int i=0;i<N;i++){
           printf("%d ",*(input+i));
    }
    
}

