#include<stdio.h>
#include<stdlib.h>
struct BSTnode{
    int key;
    struct BSTnode* left;
    struct BSTnode* right;
    struct BSTnode* p;
};
struct BST{
    struct BSTnode* ROOT;
};
struct BSTnode* SEARCH(struct BST* T,int k){
    struct BSTnode* root=T->ROOT;
    if(root==NULL){
        return NULL;
    }
    while(root!=NULL){
        if(root->key==k){
            return root;
        }else if(root->key>k){
            root=root->left;
        }else{
            root=root->right;
        }
    }
    return NULL;
}
struct BSTnode* CREATENODE(int k){
    struct BSTnode* K=(struct BSTnode*)calloc(1,sizeof(struct BSTnode));
    K->key=k;
    K->left=NULL;
    K->right=NULL;
    K->p=NULL;
    return K;
}
void INSERT(struct BST* T,struct BSTnode* x){
    struct BSTnode* root=T->ROOT;
    struct BSTnode* P=NULL;
    while(root!=NULL){
        P=root;
        if(x->key<=root->key){
            root=root->left;
        }else{
            root=root->right;
        }
    }
    x->p=P;
    if(P==NULL){
        T->ROOT=x;
    }else{
        if(x->key<=P->key){
            P->left=x;
        }else{
            P->right=x;
        }
    }
}
struct BSTnode* FIND_TREE_MIN(struct BSTnode* root){
    if(root->left==NULL){
        return root;
    }else{
        return FIND_TREE_MIN(root->left);
    }
}
void HELPER_TRANSPLANT(struct BST* T,struct BSTnode* u,struct BSTnode* v){
    if(u->p==NULL){
        T->ROOT=v;
    }else if(u==u->p->left){
        u->p->left=v;
    }else{
        u->p->right=v;
    }
    if(v!=NULL){
        v->p=u->p;
    }
}
void DELETE(struct BST* T,struct BSTnode* x){
    if(x==NULL){
        printf("-1\n");
        return;
    }
    printf("%d\n",x->key);
    if(x->left==NULL){
        HELPER_TRANSPLANT(T,x,x->right);
    }else if(x->right==NULL){
        HELPER_TRANSPLANT(T,x,x->left);
    }else{
        struct BSTnode* k=FIND_TREE_MIN(x->right);
        if(k->p!=x){
            HELPER_TRANSPLANT(T,k,k->right);
            k->right=x->right;
            k->right->p=k;
        }
            HELPER_TRANSPLANT(T,x,k);
            k->left=x->left;
            k->left->p=k;
    }
    x->left=NULL;
    x->right=NULL;
    x->p=NULL;
    free(x);
    return;
}
void INORDER(struct BSTnode* T){
    if(T==NULL){
        return;
    }else{
        INORDER(T->left);
        printf("%d ",T->key);
        INORDER(T->right);
    }
}
void PREORDER(struct BSTnode* T){
    if(T==NULL){
        return;
    }else{
        printf("%d ",T->key);
        PREORDER(T->left);
        PREORDER(T->right);
    }
}
void POSTORDER(struct BSTnode* T){
    if(T==NULL){
        return;
    }else{
        POSTORDER(T->left);
        POSTORDER(T->right);
        printf("%d ",T->key);
    }
}
int main(){
    struct BST* T=(struct BST*)calloc(1,sizeof(struct BST));
    T->ROOT=NULL;
    char c;
    scanf("%c",&c);
    while(c!='e'){
        if(c=='a'){
            int k;
            scanf("%d",&k);
            struct BSTnode* x=CREATENODE(k);
            INSERT(T,x);
        }else if(c=='s'){
            int k;
            scanf("%d",&k);
            struct BSTnode* K=SEARCH(T,k);
            if(K!=NULL){
                printf("1\n");
            }else{
                printf("-1\n");
            }
        }else if(c=='d'){
            int k;
            scanf("%d",&k);
            struct BSTnode* x=SEARCH(T,k);
            DELETE(T,x);
        }else if(c=='i'){
            INORDER(T->ROOT);
            printf("\n");
        }else if(c=='t'){
            POSTORDER(T->ROOT);
            printf("\n");
        }else if(c=='p'){
            PREORDER(T->ROOT);
            printf("\n");
        }
        scanf("%c",&c);
    }
    return 0;
}

