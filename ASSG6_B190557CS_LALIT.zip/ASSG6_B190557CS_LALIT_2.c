#include <stdio.h>
#include <stdlib.h>
struct node{
    int key;
    struct node* prev;
    struct node* next;
};
struct Doubly_linked_list{
    struct node* head;
};
struct node* LIST_SEARCH(struct Doubly_linked_list* L,int k){
    struct node* temp=L->head;
    if(L->head==NULL){
        return NULL;
    }
    while(temp!=NULL){
        if(temp->key==k){
            return temp;
        }else{
            temp=temp->next;
        }
   }
    return NULL;
}
struct node* CREATE_NODE(int k){
    struct node* x=(struct node*)calloc(1,sizeof(struct node));
    x->key=k;
    x->prev=NULL;
    x->next=NULL;
    return x;
}
void LIST_INSERT_FRONT(struct Doubly_linked_list* L,struct node* x){
    if(L->head==NULL){
        L->head=x;
        return;
    }
    L->head->prev=x;
    x->next=L->head;
    L->head=x;
    return;
}
void LIST_INSERT_TAIL(struct Doubly_linked_list* L,struct node* x){
    if(L->head==NULL){
        L->head=x;
        return;
    }
    struct node* temp=L->head;
    while(temp->next!=NULL){
        temp=temp->next;
    }
    x->prev=temp;
    temp->next=x;
    return;
}
void LIST_INSERT_AFTER(struct Doubly_linked_list* L,struct node *x,struct node* y){
    if(y==NULL){
        return;
    }
    if(y->next==NULL){
        x->prev=y;
        y->next=x;
        return;
    }
    x->next=y->next;
    y->next->prev=x;
    x->prev=y;
    y->next=x;
    return;
}
void LIST_INSERT_BEFORE(struct Doubly_linked_list* L,struct node* x,struct node* y){
    if(y==NULL){
        return;
    }
    if(L->head==y){
        x->next=y;
        y->prev=x;
        L->head=x;
        return;
    }
    y->prev->next=x;
    x->prev=y->prev;
    x->next=y;
    y->prev=x;
    return;
}
void LIST_DELETE(struct Doubly_linked_list* L,struct node* x){
    if(L->head==NULL){
        printf("-1\n");
        return;
    }
    if(x==NULL){
        printf("-1\n");
        return;
    }
    if(L->head==x){
        L->head=x->next;
        x->next->prev=NULL;
        x->next=NULL;
        printf("%d\n",x->key);
        free(x);
        return;
    }
    if(x->next==NULL){
        x->prev->next=NULL;
        x->prev=NULL;
        printf("%d\n",x->key);
        free(x);
        return;
    }
    struct node* temp=x->prev;
    temp->next=x->next;
    x->next->prev=temp;
    x->next=NULL;
    x->prev=NULL;
    printf("%d\n",x->key);
    free(x);
    return;
}
void LIST_DELETE_INITIAL(struct Doubly_linked_list* L){
    if(L->head==NULL){
        printf("-1\n");
        return;
    }
    printf("%d\n",L->head->key);
    if(L->head->next==NULL){
        free(L->head);
        L->head=NULL;
        return;
    }
    struct node* temp=L->head;
    struct node* newhead=L->head->next;
    newhead->prev=NULL;
    temp->next=NULL;
    free(temp);
    L->head=newhead;
    return;
}
void LIST_DELETE_LAST(struct Doubly_linked_list* L){
    if(L->head==NULL){
        printf("-1\n");
        return;
    }
    struct node* last=L->head;
    struct node* secondlast=NULL;
    while(last->next!=NULL){
        secondlast=last;
        last=last->next;
    }
   if(secondlast==NULL){
       last->prev=NULL;
       printf("%d\n",last->key);
       free(last);
       L->head=NULL;
       return;
   }
    printf("%d\n",last->key);
    secondlast->next=NULL;
    last->prev=NULL;
    free(last);
    return;
}

int main(){
    struct Doubly_linked_list *L=(struct Doubly_linked_list*)calloc(1,sizeof(struct Doubly_linked_list));
    L->head=NULL;
    char w;
    scanf("%c",&w);
    while(w!='e'){
        if(w=='f'){
            int x;
            scanf("%d",&x);
            struct node* X=CREATE_NODE(x);
            LIST_INSERT_FRONT(L,X);
        }else if(w=='t'){
            int x;
            scanf("%d",&x);
            struct node* X=CREATE_NODE(x);
            LIST_INSERT_TAIL(L,X);
        }else if(w=='a'){
            int x,y;
            scanf("%d %d",&x,&y);
            struct node* X=CREATE_NODE(x);
            struct node* Y=LIST_SEARCH(L,y);
            LIST_INSERT_AFTER(L,X,Y);
        }else if(w=='b'){
            int x,y;
            scanf("%d %d",&x,&y);
            struct node* X=CREATE_NODE(x);
            struct node* Y=LIST_SEARCH(L,y);
            LIST_INSERT_BEFORE(L,X,Y);
        }else if(w=='d'){
            int k;
            scanf("%d",&k);
            struct node* X=LIST_SEARCH(L,k);
            LIST_DELETE(L,X);
        }else if(w=='i'){
            LIST_DELETE_INITIAL(L);
        }else if(w=='l'){
            LIST_DELETE_LAST(L);
        }else if(w=='s'){
            int k;
            scanf("%d",&k);
            struct node* check=LIST_SEARCH(L,k);
            if(check!=NULL){
                printf("1\n");
            }else{
                printf("-1\n");
            }
        }
       scanf("%c",&w);
    }
    return 0;
}
