 #include <stdio.h>
 #include <stdlib.h>
 struct node{
     int key;
     struct node* next;
 };
 struct SINGLY_LINKED_LIST{
     struct node* head;
 };
struct node* LIST_SEARCH(struct SINGLY_LINKED_LIST* L,int k){
    struct node* temp=L->head;
    if(L->head==NULL){
        return NULL;
    }
    while(temp!=NULL){
        if(temp->key==k){
            return temp;
        }else{
            temp=temp->next;
        }
   }
    return NULL;
}
struct node* CREATE_NODE(int k){
     struct node* x=(struct node*)calloc(1,sizeof(struct node));
     x->key=k;
     x->next=NULL;
     return x;
 }
 void LIST_INSERT_FRONT(struct SINGLY_LINKED_LIST* L,struct node *x){
     if(L->head==NULL){
         L->head=x;
         return;
     }
     x->next=L->head;
     L->head=x;
 }
 void LIST_INSERT_TAIL(struct SINGLY_LINKED_LIST* L,struct node *x){
     if(L->head==NULL){
         L->head=x;
         return;
     }
     struct node* temp=L->head;
     while(temp->next!=NULL){
         temp=temp->next;
     }
     temp->next=x;
     return;
 }
 void LIST_INSERT_AFTER(struct SINGLY_LINKED_LIST* L,struct node *x,struct node *y){
    if(y==NULL){
        return;
    }
    x->next=y->next;
    y->next=x;
    return;
 }
 void LIST_INSERT_BEFORE(struct SINGLY_LINKED_LIST* L,struct node *x,struct node *y){
     if(y==NULL){
         return;
     }
     if(L->head==y){
         x->next=y;
         L->head=x;
         return;
     }
     struct node* temp=L->head;
     while(temp->next!=y){
         temp=temp->next;
     }
     x->next=y;
     temp->next=x;
     return;
 }
 void LIST_DELETE(struct SINGLY_LINKED_LIST* L,struct node *x){
     if(L->head==NULL){
         printf("-1\n");
         return;
     }
     if(x==NULL){
         printf("-1\n");
         return;
     }
     if(L->head==x){
         L->head=x->next;
         x->next=NULL;
         printf("%d\n",x->key);
         free(x);
         return;
     }
     struct node* temp=L->head;
     while(temp->next!=x){
         temp=temp->next;
     }
     temp->next=x->next;
     x->next=NULL;
     printf("%d\n",x->key);
     free(x);
     return;
 }
void LIST_DELETE_INITIAL(struct SINGLY_LINKED_LIST* L){
     if(L->head==NULL){
         printf("-1\n");
         return;
     }
     printf("%d\n",L->head->key);
     struct node* temp=L->head;
     struct node* newhead=L->head->next;
     temp->next=NULL;
     free(temp);
     L->head=newhead;
 }
void LIST_DELETE_LAST(struct SINGLY_LINKED_LIST* L){
     if(L->head==NULL){
         printf("-1\n");
         return;
     }
     struct node* last=L->head;
     struct node* secondlast=NULL;
     while(last->next!=NULL){
         secondlast=last;
         last=last->next;
     }
    if(secondlast==NULL){
        L->head=secondlast;
        printf("%d\n",last->key);
        free(last);
        return;
    }
     printf("%d\n",last->key);
     secondlast->next=NULL;
     free(last);
     return;
}
 int main(){
     struct SINGLY_LINKED_LIST *L=(struct SINGLY_LINKED_LIST*)calloc(1,sizeof(struct SINGLY_LINKED_LIST));
     L->head=NULL;
     char w;
     scanf("%c",&w);
     while(w!='e'){
         if(w=='f'){
             int x;
             scanf("%d",&x);
             struct node* X=CREATE_NODE(x);
             LIST_INSERT_FRONT(L,X);
         }else if(w=='t'){
             int x;
             scanf("%d",&x);
             struct node* X=CREATE_NODE(x);
             LIST_INSERT_TAIL(L,X);
         }else if(w=='a'){
             int x,y;
             scanf("%d %d",&x,&y);
             struct node* X=CREATE_NODE(x);
             struct node* Y=LIST_SEARCH(L,y);
             LIST_INSERT_AFTER(L,X,Y);
         }else if(w=='b'){
             int x,y;
             scanf("%d %d",&x,&y);
             struct node* X=CREATE_NODE(x);
             struct node* Y=LIST_SEARCH(L,y);
             LIST_INSERT_BEFORE(L,X,Y);
         }else if(w=='d'){
             int k;
             scanf("%d",&k);
             struct node* X=LIST_SEARCH(L,k);
             LIST_DELETE(L,X);
         }else if(w=='i'){
             LIST_DELETE_INITIAL(L);
         }else if(w=='l'){
             LIST_DELETE_LAST(L);
         }else if(w=='s'){
             int k;
             scanf("%d",&k);
             struct node* check=LIST_SEARCH(L,k);
             if(check!=NULL){
                 printf("1\n");
             }else{
                 printf("-1\n");
             }
         }
        scanf("%c",&w);
     }
     return 0;
 }
 
