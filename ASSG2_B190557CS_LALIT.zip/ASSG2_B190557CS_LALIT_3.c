#include <stdio.h>
#include <stdlib.h>
int binarySearch(int* input,int start,int end,int x){
    if(start>end){
        return -1;
    }
    int mid=(start+end)/2;
    if(input[mid]==x){
        int k=binarySearch(input,start,mid-1,x);
        if(k==-1){
            return mid;
        }else{
            return k;
        }
    }else if(x>input[mid]){
        return binarySearch(input,mid+1,end,x);
    }else{
        return binarySearch(input,start,mid-1,x);
    }
}
int main() {
    int N,Q;
    scanf("%d",&N);
    scanf("%d",&Q);
    int* input=(int*)malloc(N*sizeof(int));
    for(int i=0;i<N;i++){
        scanf("%d",input+i);
    }
    for(int i=0;i<Q;i++){
        int element;
        scanf("%d",&element);
        printf("%d\n",binarySearch(input,0,N-1,element));
    }
    
}



