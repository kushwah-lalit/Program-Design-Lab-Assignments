#include <stdio.h>

long fact_fun(int N){
    if(N<=1){
        return 1;
    }
    return fact_fun(N-1)*N;
}
int main() {
    int N;
    scanf("%d",&N);
    printf("%ld",fact_fun(N));
}


