#include <stdio.h>
#include <stdlib.h>
int MAX_HEAPIFY(int* A,int i){
    int lci=2*i,rci=2*i+1,nxtpi=i,ans=0;
    if(lci<=A[0]&&A[lci]>A[i]){
        nxtpi=lci;
        ans++;
    }else{
        ans++;
    }
    if(rci<=A[0]&&A[rci]>A[nxtpi]){
        nxtpi=rci;
        ans++;
    }
    if(nxtpi!=i){
        int x=A[i];
        A[i]=A[nxtpi];
        A[nxtpi]=x;
        ans+=MAX_HEAPIFY(A,nxtpi);
    }
    return ans;
}
int BUILD_MAX_HEAP(int* A){
    int ans=0;
    for(int i=A[0]/2;i>=1;i--){
        ans+=MAX_HEAPIFY(A,i);
    }
    return ans;
}
int HEAPSORT(int* A){
    int ans=BUILD_MAX_HEAP(A);
    int len=A[0];
    for(int i=len;i>=1;i--){
        A[0]=A[0]-1;
        int x=A[1];
        A[1]=A[i];
        A[i]=x;
        ans+= MAX_HEAPIFY(A,1);
    }
    return ans;
}
int main(){
    int N;
    scanf("%d",&N);
    int* input=(int*)malloc((N+1)*sizeof(int));
    input[0]=N;
    for(int i=1;i<N+1;i++){
        scanf("%d",input+i);
    }
    int ans=HEAPSORT(input);
    for(int i=1;i<N+1;i++){
        printf("%d ",input[i]);
    }
    printf("\n%d",ans);
}







