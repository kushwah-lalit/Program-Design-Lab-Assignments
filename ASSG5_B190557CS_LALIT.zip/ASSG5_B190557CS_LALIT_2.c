#include <stdio.h>
#include <stdlib.h>
void MIN_HEAPIFY(int* A,int i){
    int lci=2*i,rci=2*i+1,nxtpi=i;
    if(lci<=A[0]&&A[lci]<A[i]){
        nxtpi=lci;
    }
    if(rci<=A[0]&&A[rci]<A[nxtpi]){
        nxtpi=rci;
    }
    if(nxtpi!=i){
        int x=A[i];
        A[i]=A[nxtpi];
        A[nxtpi]=x;
        MIN_HEAPIFY(A,nxtpi);
    }
}
void HEAP_DECREASE_KEY(int* input,int i,int k){
    input[i+1]=k;
    for(int i=input[0]/2;i>=1;i--){
        MIN_HEAPIFY(input,i);
    }
}
void HEAP_MINIMUM(int* input){
    if(input[0]==0){
        printf("-1");
    }else{
        printf("%d\n",input[1]);
    }
}
void HEAP_EXTRACT_MIN(int* input){
    if(input[0]==0){
        printf("-1");
    }else{
        printf("%d\n",input[1]);
    }
    int x=input[input[0]];
    input[input[0]]=input[1];
    input[1]=x;
    input[0]--;
    MIN_HEAPIFY(input,1);
}
void MIN_HEAP_INSERT(int* input,int k){
    input[input[0]+1]=k;
    input[0]++;
    for(int i=input[0]/2;i>=1;i--){
        MIN_HEAPIFY(input,i);
    }
}
int main() {
    int* input=(int*)malloc(100000*sizeof(int));
    input[0]=0;
    char x;
    scanf("%c",&x);
    while(x!='s'){
        if(x=='i'){
            int k;
            scanf("%d",&k);
            MIN_HEAP_INSERT(input,k);
        }else if(x=='e'){
            HEAP_EXTRACT_MIN(input);
        }else if(x=='m'){
            HEAP_MINIMUM(input);
        }else if(x=='d'){
            int i,k;
            scanf("%d%d",&i,&k);
            HEAP_DECREASE_KEY(input,i,k);
        }
        scanf("%c",&x);
    }
 }
