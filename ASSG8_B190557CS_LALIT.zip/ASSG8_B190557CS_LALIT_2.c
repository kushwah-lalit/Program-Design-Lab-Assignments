#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct Stack{
    int* A;
    int top;
    int size;
};
struct Stack* CREATE(int K){
    struct Stack* S=(struct Stack*)calloc(1,sizeof(struct Stack));
    if(!S){
        return NULL;
    }
    S->top=0;
    S->size = K;
    S->A =(int*)calloc(K,sizeof(int));
    return S;
}
int Stack_Empty(struct Stack* S){
    if(S->top==0){
        return 1;
    }else{
        return 0;
    }
}
int Stack_Full(struct Stack* S){
    if(S->top==S->size){
        return 1;
    }else{
        return -1;
    }
}
void Push(struct Stack* S,int k){
    if(Stack_Full(S)==1){
        return;
    }
    S->A[S->top]=k;
    S->top++;
}
int Pop(struct Stack* S){
    if(S->top==0) {
        return '$';
    }
    S->top--;
    return S->A[S->top];
}
int ISNUM(char c){
    if(c>='0'&&c<='9'){
        return 1;
    }else{
        return 0;
    }
}
void EvaluatePostfix(char* e){
    struct Stack* S=CREATE((int)strlen(e));
    if(!S){
        return;
    }
    for(int i=0;e[i];i++){
        if(e[i]==' '){
            continue;
        }else if(ISNUM(e[i])==1){
            int num=0;
            while(ISNUM(e[i])!=0){
            num=num*10+(int)(e[i]-48);
            i++;
            }
            i--;
            Push(S,num);
        }else{
            int n1=Pop(S);
            int n2=Pop(S);
            switch(e[i]){
                case '*': Push(S,n1*n2);
                          break;
                case '/': Push(S,n2/n1);
                          break;
                case '-': Push(S,n2-n1);
                          break;
                case '+': Push(S,n1+n2);
                          break;
            }
        }
    }
    printf("%d\n",Pop(S));
    return;
}
int main(){
    char E[1000000];
    scanf("%[^\n]s",E);
    EvaluatePostfix(E);
    return 0;
}

