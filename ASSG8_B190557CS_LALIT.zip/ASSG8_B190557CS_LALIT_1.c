#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct Stack{
    int* A;
    int top;
    int size;
};
struct Stack* CREATE(int K){
    struct Stack* S= (struct Stack*)calloc(1,sizeof(struct Stack));
    if(!S){
        return NULL;
    }
    S->top=0;
    S->size = K;
    S->A = (int*)calloc(K,sizeof(int));
    return S;
}
int Stack_Empty(struct Stack* S){
    if(S->top==0){
        return 1;
    }else{
        return 0;
    }
}
int Stack_Full(struct Stack* S){
    if(S->top==S->size){
        return 1;
    }else{
        return -1;
    }
}
void Push(struct Stack* S,char k){
    if(Stack_Full(S)==1){
        return;
    }
    S->A[S->top]=k;
    S->top++;
}
char Pop(struct Stack* S){
    if(S->top==0) {
        return '$';
    }
    S->top--;
    return S->A[S->top];
}
char top(struct Stack* S){
    return S->A[S->top-1];
}
int PRECEDENCE(char c){
    switch(c){
    case '+':return 1;
    case '-':return 1;
    case '*':return 2;
    case '/':return 2;
    }
    return -1;
}
int ISLETTER(char c){
    if(c >= 'a' && c <= 'z'){
        return 1;
    }else{
        return 0;
    }
}
void InfixToPostfix(char* e){
    struct Stack* S=CREATE((int)strlen(e));
    if(!S){
        return ;
    }
    int k,i;
    for(i=0,k=0;e[i];i++){
        if(e[i] == '('){
            Push(S,e[i]);
        }else if(ISLETTER(e[i])==1){
            e[k++]=e[i];
        }else if(e[i] == ')'){
            while (!Stack_Empty(S)&&top(S)!='('){
                e[k++]=Pop(S);
            }
            if(!Stack_Empty(S)&&top(S)!='('){
                return;
            }else{
                Pop(S);
            }
        }else{
            while(!Stack_Empty(S)&&PRECEDENCE(e[i])<=PRECEDENCE(top(S))){
                e[k++]=Pop(S);
            }
            Push(S,e[i]);
        }
    }
    while(!Stack_Empty(S)){
        e[k++]=Pop(S);
    }
    e[k++]='\0';
}
int main(){
    char E[1000000];
    scanf("%s",E);
    InfixToPostfix(E);
    printf("%s",E);
    return 0;
}

