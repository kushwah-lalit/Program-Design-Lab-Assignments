#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Treenode{
    char data;
    struct Treenode *left;
    struct Treenode *right;
};
struct node{
    struct Treenode *data;
    struct node *next;
};
struct STACK{
    struct node* top;
};
struct Treenode* CREATE(char c){
    struct Treenode *k=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    k->left=0;
    k->right=0;
    k->data=c;
    return k;
}
int ISSYM(char c){
    if(c=='*' || c=='/' || c=='+' || c=='-'){
        return 1;
    }else{
        return 0;
    }
}
void Push(struct STACK *S,struct Treenode * T){
    struct node* k=(struct node*)calloc(1,sizeof(struct node));
    k->data=T;
    k->next=NULL;
    if(S->top==NULL){
        S->top=k;
    }else{
        k->next=S->top;
        S->top=k;
    }
    return;
}
struct Treenode* Pop(struct STACK *S){
    if(S->top==NULL) {
        return NULL;
    }
    struct Treenode *x=S->top->data;
    struct node* k=S->top;
    S->top=S->top->next;
    k->next=NULL;
    free(k);
    return x;
}
struct Treenode* Construct_Tree(char *e){
  struct STACK *S=(struct STACK*)malloc(1*sizeof(struct STACK));
  S->top=NULL;
  int N=(int)strlen(e);
  struct Treenode *T1=(struct Treenode*)malloc(1*sizeof(struct Treenode));
  struct Treenode *T2=(struct Treenode*)malloc(1*sizeof(struct Treenode));
  struct Treenode *T3=(struct Treenode*)malloc(1*sizeof(struct Treenode));
  for(int i=0;i<=N-1;i++){
        if(ISSYM(e[i])==0){
            T1=CREATE(e[i]);
            Push(S,T1);
        }else{
            T1=CREATE(e[i]);
            T2=Pop(S);
            T3=Pop(S);
            T1->right=T2;
            T1->left=T3;
            Push(S,T1);
        }
  }
  T1=Pop(S);
  return T1;
}
void Inorder(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        Inorder(T->left);
        printf("%c",T->data);
        Inorder(T->right);
    }
}

void Preorder(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        printf("%c",T->data);
        Preorder(T->left);
        Preorder(T->right);
    }
}
void  Postorder(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        Postorder(T->left);
        Postorder(T->right);
        printf("%c",T->data);
    }
}
int main(){
    char E[1000000];
    char c;
    scanf("%c",&c);
    struct Treenode *T =(struct Treenode*)malloc(1*sizeof(struct Treenode));
    while(c!='t'){
       if(c=='e'){
            scanf("%s",E);
            T=Construct_Tree(E);
        }else if(c=='i'){
            Inorder(T);
            printf("\n");
        }else if(c=='p'){
            Preorder(T);
            printf("\n");
        }else if(c=='s'){
            Postorder(T);
            printf("\n");
        }
        scanf("%c",&c);
    }
    return 0;
}

