#include <stdio.h>
#include <stdlib.h>
int INSERTION_SORT(int* input, int n){
    int cnt=0;
    for(int i=1;i<n;i++){
    int x=input[i];
    int j;
    for(j=i-1;j>=0;j--){
         if(x<input[j]){
             input[j+1]=input[j];
             cnt++;
         }else{
             cnt++;
             break;
         }
    }
    input[j+1]=x;
    }
    return cnt;
}
void PRINT(int* input, int n){
    for(int i=0;i<n;i++){
        printf("%d ",*(input+i));
    }
}
int main() {
    int N;
    scanf("%d",&N);
    int* input=(int*)malloc(N*sizeof(int));
    for(int i=0;i<N;i++){
        scanf("%d",input+i);
    }
    int ans=INSERTION_SORT(input,N);
    PRINT(input,N);
    printf("\n%d",ans);
}




