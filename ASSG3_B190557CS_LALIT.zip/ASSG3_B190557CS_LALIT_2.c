#include <stdio.h>
#include <stdlib.h>
int MERGE(int* input,int p,int q,int r){
    int s1 = q - p + 1,s2 = r - q,t=0;
    int* A1=(int*)malloc(s1*sizeof(int));
    int* A2=(int*)malloc(s2*sizeof(int));
    for (int i=p;i<=q;i++){
        A1[t++]=input[i];
    }
    t=0;
    for (int i=q+1;i<=r;i++){
        A2[t++]=input[i];
    }
    int i=0,j=0,k=p,cnt=0;
    while(i<s1&&j<s2) {
            if (A1[i]<A2[j]) {
                input[k++]=A1[i++];
                cnt++;
            }
            else {
                input[k++]=A2[j++];
                cnt++;
            }
    }
    while(i<s1) {
        input[k++]=A1[i++];
        cnt++;
    }
    while(j<s2) {
        input[k++]=A2[j++];
        cnt++;
    }
    return cnt;
}
int MERGE_SORT(int* input,int p,int r){
    if(p>=r){
       return 0;
    }
    int q=(p+r)/2;
    int ans=0;
    ans+=MERGE_SORT(input,p,q);
    ans+=MERGE_SORT(input,q+1,r);
    ans+=MERGE(input,p,q,r);
    return ans;
}
void PRINT(int* input, int n){
    for(int i=0;i<n;i++){
        printf("%d ",*(input+i));
    }
}
int main() {
    int N;
    scanf("%d",&N);
    int* input=(int*)malloc(N*sizeof(int));
    for(int i=0;i<N;i++){
        scanf("%d",input+i);
    }
    int ans=MERGE_SORT(input,0,N-1);
    PRINT(input,N);
    printf("\n%d",ans);
}





