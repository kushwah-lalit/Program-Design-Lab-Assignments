#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node* next;
};
struct STACK{
    struct node* top;
};
struct node* CREATE_NODE(int k){
     struct node* x=(struct node*)malloc(1*sizeof(struct node));
     x->data=k;
     x->next=NULL;
     return x;
 }
void Stack_Empty(struct STACK* S){
    if(S->top==NULL){
        printf("-1\n");
    }else{
        printf("1\n");
    }
    return;
}
void Push(struct STACK* S, struct node* x){
    if(S->top==NULL) {
        S->top=x;
        return;
    }else{
        x->next=S->top;
        S->top=x;
        return;
    }
}
void Pop(struct STACK* S){
    if(S->top==NULL) {
        printf("-1\n");
        return;
    }
    int x=S->top->data;
    struct node* k=S->top;
    S->top=S->top->next;
    k->next=NULL;
    free(k);
    printf("%d\n",x);
    return;
}
int main() {
    struct STACK *S=(struct STACK*)malloc(1*sizeof(struct STACK));
    S->top=NULL;
    char k;
    scanf("%c",&k);
    while(k!='t'){
        if(k=='i'){
            int w;
            scanf("%d",&w);
            struct node* x=CREATE_NODE(w);
            Push(S,x);
        }else if(k=='d'){
            Pop(S);
        }else if(k=='e'){
            Stack_Empty(S);
        }
        scanf("%c",&k);
    }
    return 0;
}

