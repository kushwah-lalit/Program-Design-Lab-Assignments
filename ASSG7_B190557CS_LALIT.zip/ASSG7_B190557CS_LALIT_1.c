#include <stdio.h>
#include <stdlib.h>
struct Stack{
    int* A;
    int top;
    int size;
};
void Stack_Empty(struct Stack* S){
    if(S->top==0){
        printf("-1\n");
    }else{
        printf("1\n");
    }
    return;
}
int Stack_Full(struct Stack* S){
    if(S->top==S->size){
        return 1;
    }else{
        return -1;
    }
}
void Push(struct Stack* S,int k){
    if(Stack_Full(S)==1){
        return;
    }
    S->A[S->top]=k;
    S->top++;
}
void Pop(struct Stack* S){
    if(S->top==0) {
        printf("-1\n");
        return;
    }
    S->top--;
    printf("%d\n",S->A[S->top]);
    S->A[S->top]=-1;
    return;
}
int main() {
    int n;
    scanf("%d",&n);
    int* arr=(int*)malloc(n*sizeof(int));
    for(int i=0;i<n;i++){
        arr[i]=-1;
    }
    struct Stack* S=(struct Stack*)malloc(1*sizeof(struct Stack));
    S->A=arr;
    S->top=0;
    S->size=n;
    char x;
    scanf("%c",&x);
    while(x!='t'){
        if(x=='i'){
            int w;
            scanf("%d",&w);
            Push(S,w);
        }else if(x=='d'){
            Pop(S);
        }else if(x=='e'){
            Stack_Empty(S);
        }
        scanf("%c",&x);
    }
    return 0;
}





