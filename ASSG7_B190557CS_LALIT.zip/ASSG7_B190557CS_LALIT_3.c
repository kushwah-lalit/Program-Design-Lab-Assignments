#include <stdio.h>
#include <stdlib.h>
struct QUEUE{
    int* A;
    int head;
    int tail;
    int size;
    int capacity;
};
void QueueEmpty(struct QUEUE* Q){
    if(Q->size==0){
        printf("-1\n");
    }else{
        printf("1\n");
    }
    return;
}
int QueueFull(struct QUEUE* Q){
    if(Q->size==Q->capacity){
        return -1;
    }else{
        return 1;
    }
}
void Enqueue(struct QUEUE* Q,int k){
    if(QueueFull(Q)==-1){
        printf("-1\n");
        return;
    }
    Q->A[Q->tail] = k;
    Q->tail=(Q->tail+1)%Q->capacity ;
    if(Q->head==-1) {
        Q->head=0;
    }
    Q->size++;
}
void Dequeue(struct QUEUE* Q){
    if(Q->size==0){
        printf("-1\n");
        return;
    }
    int x=Q->A[Q->head];
    Q->size--;
    Q->head=(Q->head+1)%Q->capacity;
    if(Q->size==0) {
        Q->head=-1;
        Q->tail= 0;
    }
    printf("%d\n",x);
    return;
}
int main() {
    int n;
    scanf("%d",&n);
    int* arr=(int*)malloc(n*sizeof(int));
    for(int i=0;i<n;i++){
        arr[i]=-1;
    }
    struct QUEUE* Q=(struct QUEUE*)malloc(1*sizeof(struct QUEUE));
    Q->size=0;
    Q->capacity=n;
    Q->A=arr;
    Q->head=-1;
    Q->tail=0;
    char x;
    scanf("%c",&x);
    while(x!='t'){
        if(x=='i'){
            int w;
            scanf("%d",&w);
            Enqueue(Q,w);
        }else if(x=='d'){
            Dequeue(Q);
        }else if(x=='f'){
            printf("%d\n",QueueFull(Q));
        }else if(x=='e'){
            QueueEmpty(Q);
        }
        scanf("%c",&x);
    }
    return 0;
}


