#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node* next;
};
struct QUEUE{
    struct node* head;
    struct node* tail;
};
struct node* CREATE_NODE(int k){
     struct node* x=(struct node*)malloc(1*sizeof(struct node));
     x->data=k;
     x->next=NULL;
     return x;
 }
void QueueEmpty(struct QUEUE* Q){
    if(Q->head==NULL){
        printf("-1\n");
    }else{
        printf("1\n");
    }
    return;
}
void Enqueue(struct QUEUE* Q, struct node* x){
    if(Q->head==NULL){
        Q->head=x;
        Q->tail=x;
    }else{
        Q->tail->next=x;
        Q->tail=x;
    }
    return;
}
void Dequeue(struct QUEUE* Q){
    if(Q->head==NULL) {
        printf("-1\n");
        return;
    }
    struct node *x=Q->head;
    int k=Q->head->data;
    Q->head=Q->head->next;
    x->next=NULL;
    free(x);
    printf("%d\n",k);
    return;
}
int main() {
    struct QUEUE *Q=(struct QUEUE*)malloc(1*sizeof(struct QUEUE));
    Q->head=NULL;
    Q->tail=NULL;
    char k;
    scanf("%c",&k);
    while(k!='t'){
        if(k=='i'){
            int w;
            scanf("%d",&w);
            struct node* x=CREATE_NODE(w);
            Enqueue(Q,x);
        }else if(k=='d'){
            Dequeue(Q);
        }else if(k=='e'){
            QueueEmpty(Q);
        }
        scanf("%c",&k);
    }
    return 0;
}



