#include <stdio.h>
#include <stdlib.h>
int PARTITION(int* A,int p,int q,int r){
    if(p>=r){
        return 0;
    }
    int i=p-1,ans=0;
    for(int j=p;j<r;j++){
        if(A[j]<=A[r]){
            i++;
            int temp=A[i];
            A[i]=A[j];
            A[j]=temp;
        }
        ans++;
    }
    int temp=A[q];
    A[q]=A[r];
    A[r]=temp;
    return ans;
}
int QUICK_SORT(int* A,int p,int r){
    if(p>=r){
       return 0;
    }
    int cnt=0,ans=0;
    for(int i=p;i<r;i++){
        if(A[i]<=A[r]){
            cnt++;
        }
    }
    int q=cnt+p;
    ans+=PARTITION(A,p,q,r);
    ans+=QUICK_SORT(A,p,q-1);
    ans+=QUICK_SORT(A,q+1,r);
    return ans;
}
void PRINT(int* A, int n){
    for(int i=0;i<n;i++){
        printf("%d ",*(A+i));
    }
}
int main() {
    int N;
    scanf("%d",&N);
    int* input=(int*)malloc(N*sizeof(int));
    for(int i=0;i<N;i++){
        scanf("%d",input+i);
    }
    int ans=QUICK_SORT(input,0,N-1);
    PRINT(input,N);
    printf("\n%d",ans);
}






